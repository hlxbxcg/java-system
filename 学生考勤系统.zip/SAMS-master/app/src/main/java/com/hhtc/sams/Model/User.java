package com.hhtc.sams.Model;

public class User {
	private String ID;				
	private String PWD;				
	private String Name;			
	private String YoB;				
	private String Gender;		
	private String Remark;			
    
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getPWD() {
		return PWD;
	}
	public void setPWD(String pWD) {
		PWD = pWD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getYoB() {
		return YoB;
	}
	public void setYoB(String yoB) {
		YoB = yoB;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getRemark() {
		return Remark;
	}
	public void setRemark(String remark) {
		Remark = remark;
	}
	
}
